package days24;

import java.util.Enumeration;
import java.util.Properties;

/**
 * @author kenik
 * @date 2023. 8. 16. - 오전 11:36:33
 * @subject
 * @content
 */
public class Ex02 {

	public static void main(String[] args) {
		// [Properties 컬렉션클래스]
		// setProperty(), getProperty()
		// key "user.dir"
		
		//                                     .  현재 디렉토리
		//                                     .. 상위 디렉토리
		// ~~~\\javaPro = 기본 폴더 
		// value "E:\Class\SS19Class\Workspace\JavaClass\javaPro"
		/*
		String userDir = System.getProperty("user.dir");
		System.out.println( userDir );
		*/
		
		Properties  sysProps = System.getProperties();
		Enumeration<Object> en = sysProps.keys();
		while (en.hasMoreElements()) {
			String key = (String) en.nextElement();
			String value = System.getProperty(key);
			System.out.printf("%s : %s\n", key, value);
		} // while

	} // main

} // class







