package days24;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Set;

/**
 * @author kenik
 * @date 2023. 8. 16. - 오전 7:05:09
 * @subject
 * @content
 */
public class Ex01 {
	
	public static void main(String[] args) {
		
		String fileName = ".\\src\\days24\\1. Java 팀 구성.txt";
		
		// [ 자바 IO(Input Output) ]
		// FileReader, BufferedReader(보조스트림)
		// FileWriter, BufferedWriter
		ArrayList<MemberVO> teamList = null;
		HashMap<String, ArrayList<MemberVO>> teamMap = new LinkedHashMap<>(); 
		String line = null;
		String teamName = null; // key
		MemberVO memberVO =  null;
		
	    try (FileReader reader = new FileReader(fileName);BufferedReader br = new BufferedReader(reader)){
			 
	    	while ( ( line = br.readLine() ) != null &&  !line.equals("")  ) {
	    		
	    		// if(  line.equals("") ) break;
	    		
				 teamName = line; // key
				 // System.out.println( line );
				 
				 line = br.readLine() ; // 이경서(팀장), 신종혁, 이재영, 송해영, 신기범, 이준희, 김성준
				 String [] tNames = line.split("\\s*,\\s*");
				 teamList = new ArrayList<MemberVO>();
				 for (String tName : tNames) { 
					if( tName.contains("(팀장)")) {
						tName = tName.replace("(팀장)",""); 
						memberVO = new MemberVO(tName, "팀장");	
					}else {
						memberVO = new MemberVO(tName, "팀원");	
					}
					teamList.add(memberVO); // value
				} // foreach				 
				 
				 teamMap.put(teamName, teamList) ;
				 
			} // while	 
	    	
	    	// 출력
	    	// 11:03 수업 시작~
	    	dispTeamMember( teamMap );
		} catch (Exception e) { 
			e.printStackTrace();
		} // catch
		
		
	} // main

	private static void dispTeamMember(HashMap<String, ArrayList<MemberVO>> teamMap) {
		
		Set<Entry<String, ArrayList<MemberVO>>>  eset = teamMap.entrySet();
		Iterator<Entry<String, ArrayList<MemberVO>>> ir = eset.iterator();
		
		
		String teamName = null;
		ArrayList<MemberVO>  teamList = null;
		int teamCount = 0;
		MemberVO teamLeaderVO = null;
		String teamLeaderName = null;
		
		while (ir.hasNext()) {
			Entry<String, ArrayList<MemberVO>> entry = ir.next();
			teamName = entry.getKey();
			teamList = entry.getValue();
			teamCount = teamList.size();
			teamLeaderVO = teamList.get(0);
			teamLeaderName = teamLeaderVO.getName();
			System.out.printf("[%s(%d명):%s]\n"
					, teamName, teamCount, teamLeaderName);
			// 팀원들 출력
			// teamList.subList(1, teamCount)
			Iterator<MemberVO> ir2 = teamList.iterator();
			int seq = 1;
			
			if( ir2.hasNext() ) ir2.next(); // 팀장 읽어와서 버리겠다.
			
			while (ir2.hasNext()) {
				MemberVO memberVO = ir2.next();
				System.out.printf("  [%d] %s\n",seq++, memberVO.getName());
			} // while
			
		} // while
		
	}

} // class


/*
[3조(6명):박정호]
  [1] 이상문
  [2] 이주영
  [3] 정하영
  [4] 이동현
  [5] 주강민
[2조(7명):박민석]
  [1] 유희진
  [2] 고경림
  [3] 임경재
  [4] 이지현
  [5] 김정주
  [6] 김호영
[1조(7명):이경서]
  [1] 신종혁
  [2] 이재영
  [3] 송해영
  [4] 신기범
  [5] 이준희
  [6] 김성준 

*/






