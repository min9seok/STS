package days23;

import java.util.TreeMap;

/**
 * @author kenik
 * @date 2023. 8. 14. - 오후 4:52:02
 * @subject
 * @content
 */
public class Ex09 {

	public static void main(String[] args) {
		/*
	    중첩클래스
		제네릭스
		어노테이션
		열거형
		자바 IO
		*/
		
		// Tree + Map<K, V>
		//        Map( key + value )
		// 검색 , 범위검색, 정렬 성능 빠르다.
		
		// Sorted + Map
		// 정렬되는 맵
	} // main

} // class










