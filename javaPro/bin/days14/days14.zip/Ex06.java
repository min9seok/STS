package days14;

/**
 * @author kenik
 * @date 2023. 8. 1. - 오후 2:02:43
 * @subject
 * @content
 */
public class Ex06 {

	public static void main(String[] args) {
		
		new MyApp();
		
		System.out.println(" Ex06 end ");

	} // main

} // class
