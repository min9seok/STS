package days14;

/**
 * @author kenik
 * @date 2023. 8. 1. - 오후 3:04:53
 * @subject
 * @content
 */
public class Ex08 {

	public static void main(String[] args) {
		// Math.random();
		// Math.abs(0)
		// Math.pow(0, 0)
		// Math.max(0, 0)
		// Math.min(0, 0)
		
		// Math 클래스의 모든 필드, 메서드는 static 필드,메서드이다.
		// 객체를 생성하지 않고 클래스명.필드명, 클래스명.메서드명으로 
		// 사용이 가능했다. 

		// 인스턴스 변수 , 인스턴스메서드 사용 X
		
		// 메서드 안에서 인스턴스 변수, 인스턴스 메서드를 사용하지 않는다면  static 붙일지를 고려해 보자..
		// 객체가 공유할지 여부 ?   클래스명. 공유해서 사용... 
	} // main

} // class
