package days14;

/**
 * @author kenik
 * @date 2023. 8. 1. - 오후 3:15:23
 * @subject
 * @content
 */
public class Ex09 {

	// static main() 메서드
	public static void main(String[] args) {
		
//		Ex09 obj = new Ex09();
//		obj.sum(1, 2);
		
		// 클래스명.static메서드명()
		//Ex09.sum(1, 2);
		
	    sum(1,2);

	} // main
	
	public static int sum(int a, int b) {
		return a+b;
	}

} // class








