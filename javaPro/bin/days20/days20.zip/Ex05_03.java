package days20;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @author kenik
 * @date 2023. 8. 9. - 오후 12:09:09
 * @subject  날짜,시간 정보를 사용자가 원하는 형식 출력.
 * @content
 */
public class Ex05_03 {

	public static void main(String[] args) {
		// 1) Calendar -> Date 형변환
		
		// 2) Date -> Calendar 형변환		 
		Date today = new Date(); 
		Calendar c = Calendar.getInstance();
		c.setTime(today);
		
		

	} // main

} // class




