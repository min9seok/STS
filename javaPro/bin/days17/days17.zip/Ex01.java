package days17;

/**
 * @author kenik
 * @date 2023. 8. 4. - 오전 7:13:53
 * @subject
 * @content
 */
public class Ex01 {
	
	public static void main(String[] args) {
		// 3:15 깃, 깃허브, CLI, 이클립스~ 
		// 4:05 수업시작~ 
		// unchecked 예외
		// checked 예외 
		// 사용자 정의 예외
		
		// 막대기자르기
	} // main

} // class
