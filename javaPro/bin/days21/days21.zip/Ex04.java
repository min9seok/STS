package days21;

import java.text.MessageFormat;
import java.text.ParseException;

/**
 * @author kenik
 * @date 2023. 8. 10. - 오전 10:30:11
 * @subject
 * @content
 */
public class Ex04 {

	public static void main(String[] args) throws ParseException {
		String source = "번호:1,이름:홍길동,주소:서울 양천구 목동";
		int no;
		String name;
		String addr;
		
		// MessageFormat 형식화 클래스 X
		/*
	    int index =  source.indexOf("이름:");
	    System.out.println( index ); 
	    int beginIndex = index + "이름:".length();
	    int endIndex= source.indexOf(",", index);
	    name = source.substring(beginIndex, endIndex);
	    System.out.println(name);
		*/
		
		// MessageFormat.format(pattern, args)
		String pattern = "번호:{0},이름:{1},주소:{2}";
		MessageFormat mf = new MessageFormat(pattern);
		Object [] objArr = mf.parse(source);
		
		// Type mismatch: cannot convert from Object to int
		// ClassCastException  클래스 형변환 X

		// E, R, S, T  cast 형변환 ( 상속 관계 )
		// no   = (int) objArr[0]; // 1
		
		// "1" -> 1
		no = Integer.parseInt( objArr[0].toString() );
		name = (String) objArr[1]; // 홍길동
		addr = (String) objArr[2]; // 주소 
		
		System.out.println(no);
		System.out.println(name);
		System.out.println(addr);
		

	} // main

} // class







