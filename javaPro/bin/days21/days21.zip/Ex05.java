package days21;

import java.time.LocalDate;

/**
 * @author kenik
 * @date 2023. 8. 10. - 오전 10:49:26
 * @subject
 * @content
 */
public class Ex05 {

	public static void main(String[] args) {
		// plusXXX(), plus(), minusXXX(), minus()
		// 11:01 수업 시작~
		// 날짜와 시간 비교 : isAfter(), isBefore(), isEqual()
		// 오늘이 생일이니?
		// 1999.8.10
		// 2023.8.10
		LocalDate today = LocalDate.now();
		
		LocalDate birth = LocalDate.of(1999, 8, 1);
		birth = birth.withYear( today.getYear() );
		System.out.println(birth);
		
		System.out.println(  today.isBefore(birth) );// 생일 지낮지 않은 것.
		System.out.println(  today.isEqual(birth) ); // 오늘 생일
		System.out.println(  today.isAfter(birth) ); // 생일 지난것
		
		System.out.println( today.compareTo(birth) );// 9     양수 [0] 음수 
		

 
	} // main

} // class





