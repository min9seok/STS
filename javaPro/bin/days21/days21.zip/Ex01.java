package days21;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @author kenik
 * @date 2023. 8. 10. - 오전 7:01:04
 * @subject
 * @content
 */
public class Ex01 {
	
	public static void main(String[] args) throws ParseException {
		// String -> sdf.parse() -> Date -> Calendar -> Date -> sdf.format()-> 형식출력
		String source = "2023/08/10 (목) 12:23:01";

		String pattern = "yyyy/MM/dd (E) hh:mm:ss";
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		Date d = sdf.parse(source);
		
		// System.out.println( d.toLocaleString() );
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		
		d = c.getTime();
		
		pattern = "yyyy년 M월 d일 (E)";
		sdf = new SimpleDateFormat(pattern);
		String strD = sdf.format(d);
		System.out.println(strD); 
		
	} // main

} // class





