package days21;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

/**
 * @author kenik
 * @date 2023. 8. 10. - 오후 3:30:26
 * @subject
 * @content
 */
public class Ex14_03 {

	public static void main(String[] args) { 
		ArrayList team1 = new ArrayList(10); 
		String t1 = "이경서(팀장), 신종혁, 이재영, 송해영 , 신기범, 이준희, 김성준 ";
		t1 = t1.replaceAll("\\(팀장\\)", ""); 
		String [] t1Arr = t1.split("\\s*,\\s*");
		for (int i = 0; i < t1Arr.length; i++) {
			team1.add(t1Arr[i]);
		} 
		
		ArrayList team2 = new ArrayList(10);
		team2.add("박민석");
		team2.add("유희진");
		team2.add("고경림"); 

		ArrayList team3 = new ArrayList(10);
		team2.add("박정호");
		team2.add("이상문");
		team2.add("이주영"); 
		
		ArrayList class5 = new  ArrayList(team1);
		class5.addAll(team2);
		class5.addAll(team3);
		
		System.out.println(class5);
		
		// iterator() class5 모든 요소 출력     4:03 수업 시작~
		Iterator ir = class5.iterator();
		while (ir.hasNext()) {
			String name = (String) ir.next();
			// System.out.println(name);
		} // while
		
		System.out.println( class5.containsAll(team1) ); // true
		 
		ArrayList  class5Clone = (ArrayList) class5.clone();
		class5Clone.removeAll(team1); 
		System.out.println( class5Clone );
	 
		// class5Clone.sort(   );
		
		// Arrays.sort(null);
		// Collections.sort(class5Clone);
		// class5Clone.sort(Comparator.naturalOrder());
		class5Clone.sort( String.CASE_INSENSITIVE_ORDER );
		
		System.out.println( class5Clone );
		 
		 
	} // main 

} // class
 



