package days26;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;

/**
 * @author kenik
 * @date 2023. 8. 17. - 오후 5:32:14
 * @subject Data[InputStream]/Data[OutputStream]
 * @content 
 *          - 기본형 8가지를 읽기/쓰기 가능한 바이트 보조 스트림
 */
public class Ex02_02 {

	public static void main(String[] args) {
		
		String name ;
		int kor, eng , mat ;	
		int tot;
		double avg ;
		boolean gender ;
		
 
		String fileName = ".\\src\\days26\\student.dat"; // data   .ini
		
		try ( FileInputStream in = new FileInputStream(fileName) ;
		      DataInputStream dis = new DataInputStream(in) ){
			
			name = dis.readUTF();
			kor = dis.readInt();
			eng = dis.readInt();
			mat = dis.readInt();
			tot = dis.readInt();
			avg = dis.readDouble();
			gender = dis.readBoolean();
			 
			 System.out.printf("%s,%d,%d,%d,%d,%f,%b\n"
					 , name, kor, eng, mat, tot, avg, gender);
			
		} catch (Exception e) {
			e.printStackTrace();
		} // catch
		
		System.out.println(" end ");


	} // main

} // class









