package days26;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;

/**
 * @author kenik
 * @date 2023. 8. 17. - 오후 5:32:14
 * @subject Data[InputStream]/Data[OutputStream]
 * @content 
 *          - 기본형 8가지를 읽기/쓰기 가능한 바이트 보조 스트림
 */
public class Ex02 {

	public static void main(String[] args) {
		
		String name = "이지현";
		int kor = 32, eng = 29, mat = 40;	
		int tot = kor + eng + mat;
		double avg = (double)tot/3;
		boolean gender = false;
		
 
		String fileName = ".\\src\\days26\\student.dat"; // data   .ini
		
		try (FileOutputStream out = new FileOutputStream(fileName, true) ;
			 DataOutputStream dos = new DataOutputStream(out)){
			// 10:01 수업 시작~
			dos.writeUTF(name);
			dos.writeInt(kor);
			dos.writeInt(eng);
			dos.writeInt(mat);
			dos.writeInt(tot);
			dos.writeDouble(avg);
			dos.writeBoolean(gender);
			
			dos.flush();
			
		} catch (Exception e) {
			e.printStackTrace();
		} // catch
		
		System.out.println(" end ");


	} // main

} // class









