package days26;

/**
 * @author kenik
 * @date 2023. 8. 18. - 오후 3:51:42
 * @subject
 * @content
 */
public class Ex06_07 {
	
	public static void main(String[] args) {
		
		// [주말 과제] d28.e02_08
		// javaPro 폴더 및 모든 하위 폴더 안에 있는 모든 파일을 찾아서
		// keyword="fileName"
		// 검색 후에     파일명   라인번호 출력....
		
		// 4:05 수업 시작~ 
		
	} // main

} // class
