package days19;

import java.util.StringTokenizer;

/**
 * @author kenik
 * @date 2023. 8. 8. - 오전 11:40:44
 * @subject
 * @content
 */
public class Ex04 {

	public static void main(String[] args) {
		// StringTokenizer 클래스
		String str = "고경림,김성준,김정주,김호영";
		// String [] str.split(regex)
		
		StringTokenizer  st = new StringTokenizer(str, ",");
		
		// System.out.println( st.countTokens() ); 
		
		/*
		System.out.println(  st.nextToken() );
		System.out.println(  st.nextToken() );
		System.out.println(  st.nextToken() );
		System.out.println(  st.nextToken() );
		// NoSuchElementException 예외발생
		System.out.println(  st.nextToken() );
		*/
		
		/*
		int countToken = st.countTokens();
		for (int i = 0; i < countToken ; i++) {
			System.out.println(  st.nextToken() );
		} // for
		*/
		
		while (  st.hasMoreTokens() ) {  // true , false
			System.out.println(  st.nextToken() );
		} // while
		
		// 12:02 수업 시작


	} // main

} // class
