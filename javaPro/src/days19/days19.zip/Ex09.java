package days19;

import java.io.FileReader;

/**
 * @author kenik
 * @date 2023. 8. 8. - 오후 1:59:06
 * @subject
 * @content
 */
public class Ex09 {
	
	public static void main(String[] args) {
		// days19.Ex01.java 파일 읽어와서 
		// 알파벳 대소문자를 구분하지 않고 
		// 배열에 저장 후 ### 막대그래프를 작성.
		//   A(20) : ####################
		//   B(13) : ############ 
		// 상대경로 :    . (현재디렉토리) == ~~\javaPro
		//               ..(상위디렉토리)
		String path = ".\\src\\days19\\Ex01.java";
		int [] counts = new int[26];
		// counts[0]  'A' , 'a'
		try (FileReader fr = new FileReader(path)) {
			int code ;
			char one;
			while ( ( code = fr.read() ) != -1 ) {
				// System.out.println(code);
				one = (char)code;
				one = Character.toUpperCase(one);
				// 'A' <= one && one <= 'Z'
				if( Character.isUpperCase(one)  ) {
					counts[one-'A']++;
				}
			} // while
			
			// 막대그래프
			for (int i = 0; i < counts.length; i++) {
				System.out.printf("%c(%d) : %s\n"
						, i+'A', counts[i], "#".repeat(counts[i]) );
			} // for
			
		} catch (Exception e) {
			e.printStackTrace();
		} // catch
		
	} // main

} // class
