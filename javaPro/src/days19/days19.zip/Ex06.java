package days19;

/**
 * @author kenik
 * @date 2023. 8. 8. - 오후 12:14:48
 * @subject
 * @content
 */
public class Ex06 {
	
	public static void main(String[] args) {
		// [ 래퍼(wrapper) 클래스 ]
		// 기본 자료형 8가지 -> 래퍼 클래스
		System.out.println( Integer.MAX_VALUE );
		/*
		 * boolean  -> Boolean
		 * char 	-> Character
		 * byte 	-> Byte
		 * short 	-> Short
		 * int  	-> Integer
		 * long 	-> Long
		 * float 	-> Float
		 * double 	-> Double
		 * */
		
		// Boolean
		// Integer; // Number 클래스의 자식
		//              ㄴ BigInteger > long(8, -900~900경)
		//              ㄴ BigDecimal > double
		// 언제 BigInteger, BigDecimal 클래스 사용 ? 
		
	} // main
	
} // class 
