package days19;

import java.util.Objects;
import java.util.Random;

/**
 * @author kenik
 * @date 2023. 8. 8. - 오후 12:36:45
 * @subject
 * @content
 */
public class Ex08 {

	public static void main(String[] args) {
		// Arrays 클래스
		// [ Objects 클래스 ]
		Ex08 obj = null;
		
		// if( obj != null)  XXX
		// if( !Objects.isNull(obj) )  XXX
		// if(  Objects.nonNull(obj) )  XXX
		
		// Objects.isNull(obj)  obj 객체가 null일때 true 반환하는 메서드 : isNull()
		// Objects.nonNull()    obj 객체가 null이 아닐 때 true 
		/*
		
		if( obj == null) {
			new ~~~Exception("예외 메시지");
		}		
		this.name = name;
		*/
		
		//this.name = Objects.requireNonNull(name, "예외 메시지");
		
		// if( a!=null && a.equals(b) ){}
		// if( Objects.equals(a,b) ) {}
		
		
		// java.util.Random 클래스 
		Random rnd = new Random();
		// rnd.nextBoolean();  // true, false
		// rnd.nextInt(bound); // 0<=   정수 <bound
		// rnd.nextXXXX();

	} // main

} // class
