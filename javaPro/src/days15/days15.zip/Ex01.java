package days15;

import java.util.Arrays;

import days14.Point;

/**
 * @author kenik
 * @date 2023. 8. 2. - 오전 7:06:15
 * @subject
 * @content
 */
public class Ex01 {

	public static void main(String[] args) {
		String n = "keNik";   
		String m= "kKnie"; 
		
		char [] nArr = n.toUpperCase().toCharArray();
		char [] mArr = m.toUpperCase().toCharArray();
		Arrays.sort( nArr ); 
		Arrays.sort( mArr ); 
		n =  String.valueOf(  nArr );
		m =  String.valueOf(  mArr );
		System.out.println(  n.equals(m)  );
		
		/*
		System.out.println( n + " /  " + m);
		
		n =  n.toUpperCase();
		m =  m.toUpperCase();		
		System.out.println( n + " /  " + m);
		
		// 정렬  KENIK   문자열 정렬 X
		char [] nArr = n.toCharArray();
		Arrays.sort(nArr);		
		System.out.println(   Arrays.toString( nArr ));
		
		char [] mArr = m.toCharArray();
		Arrays.sort(mArr);		
		System.out.println(   Arrays.toString( mArr ));
		
		// char[] -> String  n, m
	    n = String.valueOf(nArr);
		m = String.valueOf(mArr);
		
		System.out.println( n + " /  " + m);
		
		*/
		

		// 11:05 수업 시작
	} // main

} // class








