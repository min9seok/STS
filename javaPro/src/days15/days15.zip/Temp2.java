package days15;

public class Temp2 extends Temp{

}
