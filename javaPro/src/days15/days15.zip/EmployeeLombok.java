package days15;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeLombok {
	 
	private String name; // 사원명
	private String address; // 주소
	private String tel;  // 연락처
	private String hiredate; // 입사일자
	 
	
	// 메서드

} // class










