package days15;

import days13.Tv;

/**
 * @author kenik
 * @date 2023. 8. 2. - 오전 11:32:39
 * @subject
 * @content
 */
public class Ex03 {

	public static void main(String[] args) {
		
		CaptionTv ctv = new CaptionTv();
		ctv.channel = 11;
		ctv.channelDown();
		System.out.println( ctv.channel );
		ctv.dispCaption("Hello World~");
		ctv.caption = true; // 자막 ON
		ctv.dispCaption("Hi~");
		

	} // main

} // class

// 자막Tv + 기존 Tv클래스
class CaptionTv extends Tv{
	boolean caption; // 자막 기능 on(true)/off(false)
	
    void dispCaption(String text) {
    	if (this.caption) {
			System.out.println(text);
		} // if
    }
}









