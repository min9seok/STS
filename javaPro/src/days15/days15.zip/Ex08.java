package days15;

/**
 * @author kenik
 * @date 2023. 8. 2. - 오후 2:40:10
 * @subject
 * @content
 */
public class Ex08 {

	public static void main(String[] args) {
		/* [1]
		Employee emp1 = new Employee("이준희", "서울 강남구", "010-1234-1234", "2022.12.12");
		emp1.dispEmpInfo();
		// Object.toString() -> Overriding
		//                       Object
		System.out.println( emp1.toString());
		System.out.println( emp1 );
		 */


		// [ is-a 관계(상속) ]
		// 정규직은 사원이다.  O

		/*
		// [2]
		Regular emp2 = new Regular("주강민", "서울 양천구", "010-3123-2311", "2021.03.21", 4000000);
		// 문제점 : 기본급 출력 X
		emp2.dispEmpInfo();
		System.out.println( emp2 ); // @toString()
		 */		

		/*
		// [3]
		// [상속 조건]
		// Employee = Regular  클래스들간의 자동형변환
		// 부모클래스 emp2 = new 자식클래스
		// [업캐스팅(upcasting)] 
		// 자동형변환
		// [이상한 점]  기본급:4000000 출력
		// Employeeㅋ클래스의 dispEmpInfo() X
		// 실제 생성된 Regular 객체의 dispEmpInfo() 메서드 호출.
		Employee emp2 = new Regular("주강민", "서울 양천구", "010-3123-2311", "2021.03.21", 4000000); 
		emp2.dispEmpInfo();
		// [업캐스팅 - 문제점]
		// emp2.getPay(); 
		 */

		// Type mismatch: cannot convert from Employee to Regular
		// 다운캐스팅(downcasting)     (cast) 강제형변환
		// Regular emp = (Regular) emp2;
		// (조건)


		/*
		// Type mismatch: cannot convert from Employee to Regular
		// java.lang.ClassCastException:
		Regular emp = (Regular) new Employee("이준희", "서울 강남구", "010-1234-1234", "2022.12.12");
		 */

		/* [참고]
		int n = 100;
		long l = n;  // long=int   타입일치하지 않아요. => 1. 자동 형변환

		// l + n   long + int 타입일치하지 않아요 => 2. 자동 형변환
		// double / int => double
		float f = (float)3.14d; // float = double  => 강제 형변환 => cast 연산자
		 */

		/*
		// [4] SalesMan, Regular, Employee
		Employee emp3 = new SalesMan("임경재", "경기도 성남시", "010-9837-2342", "2021.03.12", 500000, 20, 70000);
		emp3.dispEmpInfo();
		System.out.println( emp3.getPay() );  // X
		 */

		/*
		// [5] 
		Employee emp4= new Temp("박정호", "서울 목동", "010-2319-3422", "2020.01.01", 20, 250000);
		emp4.dispEmpInfo();
		System.out.println( emp4.getPay() ); // X
		*/


	} // main

} // class





