package days16;

/**
 * @author kenik
 * @date 2023. 8. 3. - 오전 10:46:07
 * @subject
 * @content
 */
public class Ex03 {

	public static void main(String[] args) {
		// 11:02
		// 1. 지역변수 -> 상수 (final키워드)
		final double PI = 3.141592;
		
		// 3.141592   pi
		// 3.141592   pi
		// 3.142592   pi
		// 3.141592   pi
		// 3.141592   pi

		// FinalTest.PI		

		FinalTest obj = new FinalTest();
		System.out.println( obj.PI );
		
		int value = 100;
		obj.finalTest(  value );
		
		// The final field FinalTest.PI cannot be assigned
		// obj.PI = 3.14;
		
		// Math.PI
		
		// 변수 초기화 3가지
		
		//Child c = new Child();
		 
	} // main

} // class

/*
// The type Parent is already defined
class Parent{
	
	// 재정의할 수 없는 최종(마지막) 메서드 
	final void dispA() {
		// 구현~
	}
	
}
class Child extends Parent{
 
//	@Override
//	void dispA() {
//		// 구현~
//	}
	 
}
*/

final class FinalTest{
	
	// 상수 필드
	// public static final double PI = 3.141592; // 명시적 초기화
	
	// The blank final field PI may not have been initialized
	final double PI;
	
	// 인스턴스 초기화 블럭 
	/*
	{
		PI = 3.14;
	}
	*/
	
	public FinalTest() { // 생성자 초기화
		 PI = 3.14;
	}
	
	// int value 지역변수, 매개변수
	public void finalTest(final int value) {
		//
		//
		//  value++; X
		//  value = 1000; X
	}
	
}


   
