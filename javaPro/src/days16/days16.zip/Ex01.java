package days16;

/**
 * @author kenik
 * @date 2023. 8. 3. - 오전 7:09:57
 * @subject
 * @content
 */
public class Ex01 {

	public static void main(String[] args) {
		
		// new Parent();
		
		// Up-Casting 추상클래스
	    // Parent p1 = new Child();
		
		// Child c1  = new  Descendant();
		
		Parent p1  = new  Descendant();
 
	}

}

// 상속계층도
// 자식클래스 
// 공통적인 멤버 가진 부모클래스, abstract 키워드 - 추상클래스
// 일종의 클래스
abstract class Parent{
	 // 필드
	// 메서드
	// 추상메서드
	abstract void dispA();
	abstract void dispB();
} 

abstract class Child extends Parent{

	@Override
	void dispA() { 
	}
 
	// 필드
	// 메서드
}

class Descendant extends Child{

	@Override
	void dispB() { 
		
	}
	
}

/*
class Child extends Parent{

	@Override
	void dispA() { 
	}

	@Override
	void dispB() {  
	}
	// 필드
	// 메서드
}
*/

/*
abstract class Child extends Parent{
	// 필드
	// 메서드
}
*/


