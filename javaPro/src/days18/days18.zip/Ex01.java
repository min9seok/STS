package days18;

import java.util.Arrays;
import java.util.Collections;
import java.util.stream.Stream;

/**
 * @author kenik
 * @date 2023. 8. 7. - 오전 7:05:30
 * @subject
 * @content
 */
public class Ex01 {

	public static void main(String[] args) {
		
		int [] m = { 3, 5, 2, 4,  1 };
		System.out.println( Arrays.toString( m ) );
		Arrays.sort(m);
		System.out.println( Arrays.toString( m ) );
		
		/*[1]
		int [] temp = new int[m.length];		 
		for (int i = m.length-1 ; i >= 0; i--) {
			temp[4-i] = m[i];
		} // for		
		System.out.println( Arrays.toString(temp) );
		*/
		
		// [이유 이해]
		// The method sort(int[]) in the type Arrays is not applicable for the arguments (int[], Collections.reverseOrder
		// Arrays.sort(m, Collections.reverseOrder());
		// System.out.println( Arrays.toString(m) );
		
		// int[] -> Integer [] 변환
		// 박싱 언박싱
		Integer [] temp = Arrays.stream(m).boxed().toArray(Integer[]::new);
		Arrays.sort(temp, Collections.reverseOrder());
		System.out.println( Arrays.toString(temp) );
		
		// 11:05 수업시작~
	//  Integer []  -> int [] 변환
		m = Stream.of(temp).mapToInt(Integer::intValue).toArray();
		System.out.println( Arrays.toString(m));

	} // main 

} // class






