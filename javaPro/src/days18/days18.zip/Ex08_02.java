package days18;

import java.util.Enumeration;

/**
 * @author kenik
 * @date 2023. 8. 7. - 오후 2:35:45
 * @subject
 * @content
 */
public class Ex08_02 {

	public static void main(String[] args) {
		// 암기
		String dir = System.getProperty("user.dir");
		System.out.println( dir );
		// "E:\Class\SS19Class\Workspace\JavaClass\javaPro"
		
		String sep = System.getProperty("file.separator")  ;  // "\\"
		
		String directory = "C:\\temp\\days09";
		String fileName = "Ex01.java";
		
		// char   directory.charAt(directory.length()-1) == '\\'
		// String directory.substring(directory.length()-1).equals("\\")
		
		String path ;
		if( directory.endsWith(sep) ) {
			path = directory + fileName;
		}else {
			path = directory + sep + fileName;
		} 
		
		System.out.println( path );
		//  "C:\\temp\\days09\\Ex01.java"
		 
	} // main

} // class
