package days18;

import java.util.Arrays;

/**
 * @author kenik
 * @date 2023. 8. 7. - 오후 3:05:22
 * @subject
 * @content
 */
public class Ex08_03 {

	public static void main(String[] args) {
		
		String s = "안녕하세요. 입니다. 입니다. 입니다.";		
		String name = "홍길동";
		/*
		// 첫 번째 "입니다."을 찾아서 앞에 "홍길동"
		// "안녕하세요. 홍길동입니다. 입니다. 입니다.";
		
		// int index = s.indexOf('입');
		int index = s.indexOf("입니다"); // 7
		s = s.substring(0, index) + name + s.substring(index);
		*/
		
		// (문제)
		// 마지막 "입니다" 찾아서 그 앞에 "홍길동" 
		// "안녕하세요. 입니다. 입니다. 홍길동입니다.";
		/*
		String [] sArr =  s.split("입니다");
		System.out.println( Arrays.toString(sArr) );
		*/
		
		/*
		int index = s.lastIndexOf("입니다");
		System.out.println(index);
		s = s.substring(0, index) + name + s.substring(index);
				
		System.out.println(s);
		*/
		/*
		int fromIndex = 0 ; 
		int index = s.indexOf("입니다", fromIndex);
		System.out.println( index); // 7
		fromIndex = index + "입니다".length();
		int index = s.indexOf("입니다", fromIndex);
		System.out.println( index); // 7
		:
		:
		*/
		
		int fromIndex = 0 ;
		int index = -1;
		while(( index = s.indexOf("입니다", fromIndex) )!= -1) {
			System.out.println( index);
			fromIndex = index + "입니다".length();
		}
		
		// 메서드    : indexOf( )
		// 매개변수  : String target, String sw, int no
		// 리턴값    : int index;
		
		
		"abc".toUpperCase();  // "ABC"
		"Abc".toLowerCase();  // "abc"
		
		// String [] "홍길동,김길동,이길동".split(regex)
		
		
		String [] nameArr = "홍길동,김길동,이길동,박길동".split(",", 2);
		for (int i = 0; i < nameArr.length; i++) {
			System.out.println( nameArr[i]);
		} // for
		
	} // main

} // class





