package days18;

/**
 * @author kenik
 * @date 2023. 8. 7. - 오후 12:45:59
 * @subject
 * @content
 */
public class Ex08 {

	public static void main(String[] args) {
		// [ 문자열 다루는 클래스 ]
		// String : *** 변경 불가능한 클래스 ***
		// StringBuffer
		// StringBuilder
		// StringTokenizer

		String name = "홍길동"; // new String("홍길동");
		name += "님";
		name += " 안녕!!";

		System.out.println( name );

		// 1. 
		System.out.println(name.length()); // 9
		// 2.  name.length        필드 X
		// 2.  name.length()      메서드 O
		for (int i = 0; i < name.length() ; i++) {
			System.out.printf("name[%d]='%c'\n", i, name.charAt(i));
		} // for
		// 3. 
		String rrn = "890223-1700001";
		System.out.println(  rrn.substring(rrn.length()-1) );  // "1"

		System.out.println(  rrn.substring(7) );  // "1"

		// beginIndex <=,   < endIndex
		System.out.println( rrn.substring(0,2));

		// 4.  정규식 패턴 일치 여부 체크 : String.matches()
		String regex = "\\d{6}-\\d{7}";
		System.out.println( rrn.matches(regex) ); // true

		// 5. concat()
		String a = "ㅁㅁㅁ" + "ㅠㅠㅠ" + "xxx"; 
		String b = "ㅁㅁㅁ"
				.concat("ㅠㅠㅠ")			    
				.concat("xxx");

		// 6. 
		// Stream rrn.chars();

		// 7. int  0 동일한 문자열이다.
		//       -32       X 
		//        32       X
		// "A"65    "a"97   -32
		// "a"97    "A"65   32
		System.out.println( "kenik".compareTo("kEnik") );
		System.out.println( "kenik".compareToIgnoreCase("kEnik") );

		// 8. true, false
		System.out.println("kenik".equals("kEnik"));
		System.out.println("kenik".equalsIgnoreCase("kEnik"));

		// 9. true, false
		boolean result = "안녕하세요. 홍길동입니다.".contains("김길동");
		System.out.println(result); // false
		// 10.
		String url = "http://www.naver.com/test.jsp";
		String suffix =".html"; // 접미사
		String prefix = "http://"; // 접두사
		
		System.out.println(url.startsWith(prefix)); // true
		System.out.println(url.endsWith(suffix)); // true
		
		// 11.             3:05 수업 시작


		//int [] m = { 3,5,2,4,1};
		//System.out.println( m.length );
	} // main

} // class





